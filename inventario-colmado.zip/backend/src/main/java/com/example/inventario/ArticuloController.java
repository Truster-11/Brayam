
package com.example.inventario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/articulos")
@CrossOrigin(origins = "*")
public class ArticuloController {

    @Autowired
    private ArticuloRepository repo;

    @PostMapping
    public Articulo crear(@RequestBody Articulo articulo) {
        return repo.save(articulo);
    }

    @GetMapping
    public List<Articulo> listar() {
        return repo.findAll();
    }
}
